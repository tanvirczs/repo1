let users = [];
let currentUser = null;
let helpRequests = [];

function registerUser() {
  const name = document.getElementById("register-name").value;
  const email = document.getElementById("register-email").value;
  const password = document.getElementById("register-password").value;

  if (name && email && password) {
    users.push({ name, email, password });
    alert("Registration successful! You can now log in.");
    toggleModal('registerModal');
  } else {
    alert("Please fill in all fields.");
  }
}

function loginUser() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    currentUser = user;
    alert(`Welcome, ${user.name}!`);
    toggleModal('loginModal');
  } else {
    alert("Invalid credentials. Please try again.");
  }
}

function toggleModal(id) {
  const modal = document.getElementById(id);
  modal.style.display = modal.style.display === "block" ? "none" : "block";
}

window.onclick = function (event) {
  const modals = document.querySelectorAll(".modal");
  modals.forEach(modal => {
    if (event.target === modal) {
      modal.style.display = "none";
    }
  });
};

function scrollToRequests() {
  const section = document.getElementById("help-requests");
  section.scrollIntoView({ behavior: "smooth" });
}

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showMap, showError);
  } else {
    alert("Geolocation is not supported by this browser.");
  }
}

function showMap(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;
  const iframe = document.getElementById("map-frame");
  iframe.src = `https://maps.google.com/maps?q=${lat},${lon}&z=15&output=embed`;

  window.open(`https://maps.google.com/?q=${lat},${lon}`, '_blank');
}

function showError(error) {
  alert("Error retrieving location.");
}

function requestHelp() {
  if (!currentUser) {
    alert("Please log in to request help.");
    return;
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      const helpRequest = {
        user: currentUser.name,
        location: `Lat: ${lat}, Lon: ${lon}`,
        description: `Help request from ${currentUser.name} at location: ${lat}, ${lon}`,
        timestamp: new Date().toLocaleString()
      };

      helpRequests.push(helpRequest);
      displayHelpRequests();
      alert("Help request submitted!");
    });
  } else {
    alert("Geolocation is not supported by this browser.");
  }
}

function displayHelpRequests() {
  const helpList = document.getElementById("help-list");
  helpList.innerHTML = ""; // Clear previous requests

  helpRequests.forEach(request => {
    const requestDiv = document.createElement("div");
    requestDiv.classList.add("help-request");
    requestDiv.innerHTML = `
      <p><strong>User:</strong> ${request.user}</p>
      <p><strong>Location:</strong> ${request.location}</p>
      <p><strong>Description:</strong> ${request.description}</p>
      <p><strong>Time:</strong> ${request.timestamp}</p>
    `;
    helpList.appendChild(requestDiv);
  });
}
